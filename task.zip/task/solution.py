"""
Golden reference solution for the loan-default leakage task.

This script is run by the task author / eval harness only, to confirm
the task is solvable and that a correct submission passes
tests/test_output.py. It is NOT shown to the agent under evaluation.

It trains a model using only fields that are genuinely available at
loan origination, then embeds the fitted pipeline directly inside a
generated /app/result/utils.py so the deliverable is a single
self-contained file with no external weight files, per the task's
requirements.
"""

import base64
import pickle
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DATA_PATH = Path("/app/data/dataset.csv")
OUT_PATH = Path("/app/result/utils.py")

NUMERIC_COLS = [
    "loan_amount", "term_months", "interest_rate", "installment",
    "annual_income", "debt_to_income", "credit_score",
    "employment_length_years", "num_open_accounts", "delinq_2yrs",
    "revol_util", "num_derogatory_records",
]
CATEGORICAL_COLS = ["home_ownership", "verification_status", "purpose"]

# Deliberately excluded, and never referenced below:
#   - loan_id, issue_date, last_payment_date            (identifiers / metadata)
#   - days_to_last_payment, total_recovery_amount,
#     recovery_status                                   (only known after
#                                                         the loan's outcome
#                                                         is already underway
#                                                         or known -- these
#                                                         are the columns the
#                                                         instructions warn
#                                                         about, and they will
#                                                         not be present in
#                                                         the eval-time df)
FEATURE_COLS = NUMERIC_COLS + CATEGORICAL_COLS


def build_pipeline() -> Pipeline:
    preprocessor = ColumnTransformer([
        ("num", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), NUMERIC_COLS),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_COLS),
    ])
    model = GradientBoostingClassifier(
        n_estimators=150, max_depth=3, learning_rate=0.1, random_state=0
    )
    return Pipeline([("pre", preprocessor), ("clf", model)])


def main():
    df = pd.read_csv(DATA_PATH)

    X = df[FEATURE_COLS]
    y = df["default"]

    # Preprocessing (imputer/scaler/encoder) and model are fit together,
    # in one Pipeline, on the training file only -- nothing here is
    # fit on anything resembling the held-out evaluation set.
    pipeline = build_pipeline()
    pipeline.fit(X, y)

    model_b64 = base64.b64encode(pickle.dumps(pipeline)).decode("ascii")

    module_source = f'''"""
Self-contained inference module.

The model was trained offline on origination-time features only
(see solution.py in the reference solution for training code) and is
embedded below as a base64-encoded pickled scikit-learn Pipeline.
No external files, no network access, no retraining at import time.
"""

import base64
import pickle

import pandas as pd

_MODEL_B64 = "{model_b64}"

_FEATURE_COLS = {FEATURE_COLS!r}


class _Result:
    def __init__(self):
        self._pipeline = pickle.loads(base64.b64decode(_MODEL_B64))

    def predict(self, df: pd.DataFrame):
        X = df[_FEATURE_COLS]
        return self._pipeline.predict_proba(X)[:, 1]


result = _Result()
'''

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(module_source)
    print(f"Wrote {OUT_PATH} ({len(module_source)} chars, model {len(model_b64)} b64 chars)")


if __name__ == "__main__":
    main()
