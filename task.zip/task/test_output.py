"""
Atomic tests for the loan-default leakage task.

Each test checks exactly one claim from instruction.md, and each is
independent (no test depends on another having run first, no shared
mutable state). A submission passes the task iff every test here
passes.

Assumes the submission has already produced /app/result/utils.py
inside the container. This file is run by the grading harness, not by
the agent -- neither this file nor holdout_eval.csv should be present
anywhere inside the agent's own working environment.
"""

import ast
import importlib.util
import shutil
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import roc_auc_score

SUBMISSION_PATH = Path("/app/result/utils.py")
HOLDOUT_PATH = Path(__file__).parent / "holdout_eval.csv"

FEATURE_COLS = [
    "loan_amount", "term_months", "interest_rate", "installment",
    "annual_income", "debt_to_income", "credit_score",
    "employment_length_years", "num_open_accounts", "delinq_2yrs",
    "revol_util", "num_derogatory_records",
    "home_ownership", "verification_status", "purpose",
]

# Performance bands. The golden solution scores ~0.75 AUC on this
# holdout; a model that ignored the signal entirely lands at ~0.50;
# a model that got hold of leak-equivalent information lands >=0.90.
BASELINE_AUC = 0.50
MIN_ACCEPTABLE_AUC = 0.65   # must clear baseline by a real margin
LEAK_CEILING_AUC = 0.85     # at/above this implies leakage, not skill

# Only these THIRD-PARTY top-level packages may be imported by the
# submission, per "depend only on numpy, pandas, and scikit-learn at
# prediction time". Standard-library modules are unrestricted.
ALLOWED_THIRD_PARTY_IMPORTS = {"numpy", "pandas", "sklearn"}
STDLIB_ALLOWLIST = {
    "pickle", "base64", "math", "json", "os", "sys", "typing",
    "functools", "itertools", "collections", "re", "warnings", "copy",
    "dataclasses", "abc", "io",
}
# Explicitly disallowed regardless of category (network / external I/O)
FORBIDDEN_MODULES = {
    "requests", "urllib", "urllib2", "socket", "http", "ftplib",
    "joblib", "torch", "tensorflow", "xgboost", "lightgbm", "catboost",
}


# ---------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------

@pytest.fixture(scope="module")
def submission_source() -> str:
    assert SUBMISSION_PATH.exists(), (
        f"Expected deliverable at {SUBMISSION_PATH}, but it does not exist."
    )
    return SUBMISSION_PATH.read_text()


@pytest.fixture(scope="module")
def result_module():
    """
    Import the submission the same way the eval harness will: as a
    standalone module, from its real path (needed for the pickle/base64
    self-containment check to be meaningful).
    """
    spec = importlib.util.spec_from_file_location("submission_utils", SUBMISSION_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def holdout_df() -> pd.DataFrame:
    assert HOLDOUT_PATH.exists(), f"Missing holdout file at {HOLDOUT_PATH}"
    return pd.read_csv(HOLDOUT_PATH)


@pytest.fixture(scope="module")
def holdout_X_y(holdout_df):
    X = holdout_df[FEATURE_COLS].copy()
    y = holdout_df["default"].copy()
    return X, y


@pytest.fixture(scope="module")
def predictions(result_module, holdout_X_y):
    X, _ = holdout_X_y
    return np.asarray(result_module.result.predict(X))


# ---------------------------------------------------------------------
# Structural / interface tests
# ---------------------------------------------------------------------

def test_deliverable_file_exists():
    assert SUBMISSION_PATH.exists(), (
        "instruction.md requires writing /app/result/utils.py"
    )


def test_module_exposes_result_object(result_module):
    assert hasattr(result_module, "result"), (
        "utils.py must expose a module-level object named `result`"
    )


def test_result_has_predict_method(result_module):
    assert hasattr(result_module.result, "predict"), (
        "`result` must implement a `predict` method"
    )
    assert callable(result_module.result.predict)


def test_predict_accepts_origination_only_columns(result_module, holdout_X_y):
    """
    The core leakage trap: the eval-time df contains ONLY pre-origination
    columns. If the submission's predict() reaches for a servicing-history
    or outcome-related column, this call raises and the test fails.
    """
    X, _ = holdout_X_y
    try:
        result_module.result.predict(X)
    except Exception as e:
        pytest.fail(
            "predict() failed when called with only the columns genuinely "
            f"available at origination (no leak/servicing columns present). "
            f"This usually means the model was trained on a column that "
            f"will not exist at evaluation time. Original error: {e!r}"
        )


def test_predict_output_length_and_order(predictions, holdout_X_y):
    X, _ = holdout_X_y
    assert len(predictions) == len(X), (
        f"predict() must return one prediction per input row: "
        f"got {len(predictions)} predictions for {len(X)} rows"
    )


def test_predict_output_is_valid_probability(predictions):
    assert np.all(predictions >= 0.0) and np.all(predictions <= 1.0), (
        "predict() must return values in [0, 1] (a probability), "
        f"got range [{predictions.min()}, {predictions.max()}]"
    )
    assert not np.any(np.isnan(predictions)), "predict() returned NaN values"


def test_predict_is_deterministic(result_module, holdout_X_y):
    X, _ = holdout_X_y
    p1 = np.asarray(result_module.result.predict(X))
    p2 = np.asarray(result_module.result.predict(X))
    assert np.allclose(p1, p2), (
        "predict() must be deterministic given the same input "
        "(grading re-runs may call predict() more than once)"
    )


def test_predict_is_column_order_invariant(result_module, holdout_X_y):
    X, _ = holdout_X_y
    X_shuffled = X[list(reversed(X.columns))]
    p_original = np.asarray(result_module.result.predict(X))
    p_shuffled = np.asarray(result_module.result.predict(X_shuffled))
    assert np.allclose(p_original, p_shuffled), (
        "predict() output should not depend on input column order"
    )


# ---------------------------------------------------------------------
# Self-containment tests ("no external weight files, no network calls,
# no retraining at import time")
# ---------------------------------------------------------------------

def test_only_allowed_third_party_imports(submission_source):
    tree = ast.parse(submission_source)
    top_level_imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                top_level_imports.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                top_level_imports.add(node.module.split(".")[0])

    forbidden_hits = top_level_imports & FORBIDDEN_MODULES
    assert not forbidden_hits, (
        f"utils.py imports disallowed module(s): {forbidden_hits}"
    )

    unknown = top_level_imports - ALLOWED_THIRD_PARTY_IMPORTS - STDLIB_ALLOWLIST
    assert not unknown, (
        f"utils.py imports module(s) outside numpy/pandas/scikit-learn "
        f"and the standard library: {unknown}"
    )


def test_self_contained_no_external_files(holdout_X_y):
    """
    Copy ONLY utils.py into an empty temp directory and import it from
    there. If the submission secretly depends on a sibling weights
    file, a relative path, or anything else living next to it in the
    original solution directory, this import will fail.
    """
    X, _ = holdout_X_y
    with tempfile.TemporaryDirectory() as tmp:
        isolated_path = Path(tmp) / "utils.py"
        shutil.copy(SUBMISSION_PATH, isolated_path)

        spec = importlib.util.spec_from_file_location("isolated_utils", isolated_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        preds = module.result.predict(X)
        assert len(preds) == len(X)


def test_import_does_not_retrain(holdout_X_y):
    """
    Proxy check for "no retraining at import time": importing the
    module (which unpickles an already-fitted model) should be fast.
    Actually fitting a model on the training file takes meaningfully
    longer than deserializing one.
    """
    with tempfile.TemporaryDirectory() as tmp:
        isolated_path = Path(tmp) / "utils.py"
        shutil.copy(SUBMISSION_PATH, isolated_path)

        start = time.monotonic()
        spec = importlib.util.spec_from_file_location("timing_utils", isolated_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        elapsed = time.monotonic() - start

    assert elapsed < 10.0, (
        f"Importing utils.py took {elapsed:.1f}s, which suggests the "
        f"submission is retraining a model at import time rather than "
        f"loading an already-fitted one, as instruction.md requires"
    )


# ---------------------------------------------------------------------
# Performance tests (the actual grading signal)
# ---------------------------------------------------------------------

def test_beats_constant_baseline(predictions, holdout_X_y):
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert auc >= MIN_ACCEPTABLE_AUC, (
        f"AUC {auc:.4f} does not clear the minimum acceptable bar "
        f"({MIN_ACCEPTABLE_AUC}); a constant-prediction baseline "
        f"scores {BASELINE_AUC}, so this model is not usefully better"
    )


def test_does_not_exceed_leak_ceiling(predictions, holdout_X_y):
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert auc < LEAK_CEILING_AUC, (
        f"AUC {auc:.4f} meets or exceeds the leak-reference ceiling "
        f"({LEAK_CEILING_AUC}). Performance this high on this dataset "
        f"is only achievable by relying on information that would not "
        f"genuinely be available at loan origination -- check for "
        f"target leakage or preprocessing fit on data outside the "
        f"training split."
    )


def test_auc_within_golden_band(predictions, holdout_X_y):
    """Single combined pass/fail signal, kept separate from the two
    tests above so a failure message pinpoints which side was violated
    without needing to read this test's internals."""
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert MIN_ACCEPTABLE_AUC <= auc < LEAK_CEILING_AUC, (
        f"AUC {auc:.4f} outside acceptable band "
        f"[{MIN_ACCEPTABLE_AUC}, {LEAK_CEILING_AUC})"
    )
