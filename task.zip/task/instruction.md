# Loan Default Prediction from Origination Data

You are given loan servicing records from a lending platform, covering loans issued over a multi-year period. Each row corresponds to one loan. Your goal is to estimate the probability that a loan will default (`target`, binary) using information available at the time the loan was originated.

## Data

`/app/data/dataset.csv`

Each row contains loan-level fields recorded at or after origination, including (but not limited to):

- Origination details: `loan_amount`, `term_months`, `interest_rate`, `installment`, `issue_date`
- Applicant details: `annual_income`, `debt_to_income`, `credit_score`, `employment_length_years`, `home_ownership`, `verification_status`, `purpose`
- Credit history: `num_open_accounts`, `delinq_2yrs`, `revol_util`, `num_derogatory_records`
- Servicing history and outcome-related fields recorded after origination
- `default` — whether the loan defaulted (target)

Not every column in this file is available at the time a new loan needs to be scored. Some fields are only recorded once a loan's outcome is already underway or known. Using such fields during model development may produce misleadingly strong results on this file that do not hold up when scoring a genuinely new loan.

The loans in this file were all issued during a specific historical window. Loans you will be asked to score at evaluation time were issued later.

## Task

Build a model that predicts default probability from information available at origination.

Your objective is **not simply to maximize performance on this file**, but to build a model that produces valid, reliable predictions for new loans being scored at origination, based only on what is actually known at that point in time.

Before submitting, it is good practice to check exactly which fields your model depends on, and whether each of those fields would realistically be known before a loan's outcome is determined.

## Deliverable

Write `/app/result/utils.py` exposing a module-level object named `result` with a `predict` method.

```python
result.predict(df)
```

`df` will contain only the fields that are genuinely available at loan origination. It will not contain servicing-history or outcome-related fields.

The method must return one predicted default probability (between 0 and 1) for each input row, preserving row order.

## Requirements

Your submitted `utils.py` should:

- depend only on `numpy`, `pandas`, and `scikit-learn` at prediction time;
- contain everything needed for inference inside the file (no external weight files, no network calls, no retraining at import time);
- expose a module-level object named `result` implementing `result.predict(df)`;
- only reference columns that will actually be present in the `df` passed at evaluation time.

## Evaluation

Evaluation measures prediction quality (ROC AUC) on held-out loans issued after the period covered by the training file. Submissions are also compared against a simple constant-prediction baseline, and against an upper reference band representing performance that is only achievable by relying on information that would not genuinely be available at origination.
