# Coffee Roast Batch Defect Prediction

You are given roasting records from a specialty coffee roastery, covering roast batches
produced over a multi-year period. Each row is one roast batch. Your goal is to estimate
the probability that a batch will be flagged defective at quality control (`defect`,
binary) using information available at the moment the roast finishes.

## Data

`/app/data/dataset.csv`

Each row contains fields recorded at or after a roast, including (but not limited to):

- Batch details: `bean_lot_id`, `roast_date`, `origin_country`, `processing_method`, `roaster_machine_id`
- Green bean properties: `green_bean_moisture_pct`, `altitude_m`
- Roast execution telemetry: `batch_weight_kg`, `charge_temp_c`, `total_roast_time_min`,
  `first_crack_time_min`, `drop_temp_c`, `ambient_humidity_pct`, `ambient_temp_c`
- Lot history: `num_prior_roasts_this_lot`, `prior_defect_ever`
- `qc_preview_score` — an internal score attached to some batches
- Cupping and outcome-related fields recorded after full quality control review
- `defect` — whether the batch was flagged defective (target)

Not every column in this file is genuinely available at the moment a freshly-roasted batch
needs to be scored. Some fields are only recorded once a batch's full quality control
review is already underway or its outcome is known. Using such fields during model
development can produce misleadingly strong results on this file that do not hold up when
scoring a real new batch — and in some cases will make your submission fail outright, since
the evaluation-time input won't contain them at all. Not all of these fields are obviously
post-roast from their name; some warrant checking their coverage and how well they line up
with the outcome before you trust them.

Some green coffee lots in this file were roasted into more than one batch over time —
you'll find repeated `bean_lot_id` values. The lots your model will be scored against at
evaluation time are entirely different coffee that never appears in this file. A feature or
encoding that relies on having seen a specific lot before will not transfer to a brand-new
one, however well it appears to perform here.

## Task

Build a model that predicts defect probability from information genuinely available the
moment a roast finishes.

Your objective is **not simply to maximize performance on this file**, but to build a model
that produces valid, reliable predictions for new batches from bean lots your model has
never encountered, based only on what is actually known at that point.

Before submitting, it is good practice to check exactly which fields and encodings your
model depends on, and whether each would realistically be known — and would generalize —
for a genuinely new lot.

## Deliverable

Write `/app/result/utils.py` exposing a module-level object named `result` with a `predict`
method.

```python
result.predict(df)
```

`df` will contain only the fields that are genuinely available when a roast finishes, for
bean lots your model has not seen before. It will not contain QC-cupping, outcome-related,
or internal-score fields that aren't genuinely available at that point.

The method must return one predicted defect probability (between 0 and 1) for each input
row, preserving row order.

## Requirements

Your submitted `utils.py` should:

- depend only on `numpy`, `pandas`, and `scikit-learn` at prediction time;
- contain everything needed for inference inside the file (no external weight files, no
  network calls, no retraining at import time);
- expose a module-level object named `result` implementing `result.predict(df)`;
- only reference columns that will actually be present in the `df` passed at evaluation
  time.

## Evaluation

Evaluation measures prediction quality (ROC AUC) on held-out batches from bean lots not
present in `/app/data/dataset.csv`. Submissions are also compared against a simple
constant-prediction baseline, and against an upper reference band representing performance
that is only achievable by relying on information — or on memorizing specific bean lots —
that would not genuinely generalize to a new batch.
