"""
Atomic tests for the coffee-roast-defect stacked-leakage task.

Each test checks exactly one claim from instruction.md, and each is
independent (no test depends on another having run first, no shared
mutable state). A submission passes the task iff every test here
passes.

Assumes the submission has already produced /app/result/utils.py
inside the container. This file is run by the grading harness, not by
the agent -- neither this file nor holdout_eval.csv should be present
anywhere inside the agent's own working environment.
"""

import ast
import importlib.util
import shutil
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import roc_auc_score

SUBMISSION_PATH = Path("/app/result/utils.py")
HOLDOUT_PATH = Path(__file__).parent / "holdout_eval.csv"

FEATURE_COLS = [
    "bean_lot_id", "roast_date", "origin_country", "processing_method",
    "green_bean_moisture_pct", "altitude_m", "batch_weight_kg", "charge_temp_c",
    "total_roast_time_min", "first_crack_time_min", "drop_temp_c",
    "ambient_humidity_pct", "ambient_temp_c", "roaster_machine_id",
    "num_prior_roasts_this_lot", "prior_defect_ever",
]

# Performance bands. The golden solution scores ~0.636 AUC on this holdout
# using only genuinely-available, genuinely-generalizable features. A model
# that ignored the signal entirely lands at ~0.50. A model that naively
# target-encodes bean_lot_id (without safeguards for unseen lots) collapses
# to ~0.52 on this holdout despite looking near-perfect in-sample, since
# every holdout lot is one it has never seen.
BASELINE_AUC = 0.50
MIN_ACCEPTABLE_AUC = 0.58   # must clear baseline by a real margin, and clears the lot-memorization collapse
LEAK_CEILING_AUC = 0.72     # at/above this implies leakage, not skill

# Only these THIRD-PARTY top-level packages may be imported by the
# submission, per "depend only on numpy, pandas, and scikit-learn at
# prediction time". Standard-library modules are unrestricted.
ALLOWED_THIRD_PARTY_IMPORTS = {"numpy", "pandas", "sklearn"}
STDLIB_ALLOWLIST = {
    "pickle", "base64", "math", "json", "os", "sys", "typing",
    "functools", "itertools", "collections", "re", "warnings", "copy",
    "dataclasses", "abc", "io",
}
FORBIDDEN_MODULES = {
    "requests", "urllib", "urllib2", "socket", "http", "ftplib",
    "joblib", "torch", "tensorflow", "xgboost", "lightgbm", "catboost",
}


# ---------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------

@pytest.fixture(scope="module")
def submission_source() -> str:
    assert SUBMISSION_PATH.exists(), (
        f"Expected deliverable at {SUBMISSION_PATH}, but it does not exist."
    )
    return SUBMISSION_PATH.read_text()


@pytest.fixture(scope="module")
def result_module():
    spec = importlib.util.spec_from_file_location("submission_utils", SUBMISSION_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def holdout_df() -> pd.DataFrame:
    assert HOLDOUT_PATH.exists(), f"Missing holdout file at {HOLDOUT_PATH}"
    return pd.read_csv(HOLDOUT_PATH)


@pytest.fixture(scope="module")
def holdout_X_y(holdout_df):
    X = holdout_df[FEATURE_COLS].copy()
    y = holdout_df["defect"].copy()
    return X, y


@pytest.fixture(scope="module")
def predictions(result_module, holdout_X_y):
    X, _ = holdout_X_y
    return np.asarray(result_module.result.predict(X))


# ---------------------------------------------------------------------
# Structural / interface tests
# ---------------------------------------------------------------------

def test_deliverable_file_exists():
    assert SUBMISSION_PATH.exists(), (
        "instruction.md requires writing /app/result/utils.py"
    )


def test_module_exposes_result_object(result_module):
    assert hasattr(result_module, "result"), (
        "utils.py must expose a module-level object named `result`"
    )


def test_result_has_predict_method(result_module):
    assert hasattr(result_module.result, "predict"), (
        "`result` must implement a `predict` method"
    )
    assert callable(result_module.result.predict)


def test_predict_accepts_roast_time_only_columns(result_module, holdout_X_y):
    """Traps 1 and 2: the eval-time df contains ONLY genuinely pre-cupping
    columns -- no QC-cupping, outcome-related, or qc_preview_score field. If
    the submission's predict() reaches for any of those, this call raises
    and the test fails."""
    X, _ = holdout_X_y
    try:
        result_module.result.predict(X)
    except Exception as e:
        pytest.fail(
            "predict() failed when called with only the columns genuinely "
            f"available when a roast finishes (no QC-cupping/outcome/internal-score "
            f"columns present). This usually means the model was trained on a "
            f"column that will not exist at evaluation time. Original error: {e!r}"
        )


def test_predict_handles_unseen_bean_lot_ids(result_module, holdout_X_y):
    """Trap 3: every bean_lot_id at evaluation time is one the model has never
    seen (a brand-new lot). If bean_lot_id was used via a raw lookup (e.g. a
    dict built from the training file with no fallback for missing keys)
    rather than something that generalizes, this call raises."""
    X, _ = holdout_X_y
    X_fabricated = X.copy()
    X_fabricated["bean_lot_id"] = [f"UNSEEN-{i:06d}" for i in range(len(X_fabricated))]
    try:
        result_module.result.predict(X_fabricated)
    except Exception as e:
        pytest.fail(
            "predict() failed when given entirely novel bean_lot_id values. "
            "A submission must not depend on having seen a specific lot "
            f"before. Original error: {e!r}"
        )


def test_predict_output_length_and_order(predictions, holdout_X_y):
    X, _ = holdout_X_y
    assert len(predictions) == len(X), (
        f"predict() must return one prediction per input row: "
        f"got {len(predictions)} predictions for {len(X)} rows"
    )


def test_predict_output_is_valid_probability(predictions):
    assert np.all(predictions >= 0.0) and np.all(predictions <= 1.0), (
        "predict() must return values in [0, 1] (a probability), "
        f"got range [{predictions.min()}, {predictions.max()}]"
    )
    assert not np.any(np.isnan(predictions)), "predict() returned NaN values"


def test_predict_is_deterministic(result_module, holdout_X_y):
    X, _ = holdout_X_y
    p1 = np.asarray(result_module.result.predict(X))
    p2 = np.asarray(result_module.result.predict(X))
    assert np.allclose(p1, p2), (
        "predict() must be deterministic given the same input "
        "(grading re-runs may call predict() more than once)"
    )


def test_predict_is_column_order_invariant(result_module, holdout_X_y):
    X, _ = holdout_X_y
    X_shuffled = X[list(reversed(X.columns))]
    p_original = np.asarray(result_module.result.predict(X))
    p_shuffled = np.asarray(result_module.result.predict(X_shuffled))
    assert np.allclose(p_original, p_shuffled), (
        "predict() output should not depend on input column order"
    )


# ---------------------------------------------------------------------
# Self-containment tests
# ---------------------------------------------------------------------

def test_only_allowed_third_party_imports(submission_source):
    tree = ast.parse(submission_source)
    top_level_imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                top_level_imports.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                top_level_imports.add(node.module.split(".")[0])

    forbidden_hits = top_level_imports & FORBIDDEN_MODULES
    assert not forbidden_hits, (
        f"utils.py imports disallowed module(s): {forbidden_hits}"
    )

    unknown = top_level_imports - ALLOWED_THIRD_PARTY_IMPORTS - STDLIB_ALLOWLIST
    assert not unknown, (
        f"utils.py imports module(s) outside numpy/pandas/scikit-learn "
        f"and the standard library: {unknown}"
    )


def test_self_contained_no_external_files(holdout_X_y):
    X, _ = holdout_X_y
    with tempfile.TemporaryDirectory() as tmp:
        isolated_path = Path(tmp) / "utils.py"
        shutil.copy(SUBMISSION_PATH, isolated_path)

        spec = importlib.util.spec_from_file_location("isolated_utils", isolated_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        preds = module.result.predict(X)
        assert len(preds) == len(X)


def test_import_does_not_retrain(holdout_X_y):
    with tempfile.TemporaryDirectory() as tmp:
        isolated_path = Path(tmp) / "utils.py"
        shutil.copy(SUBMISSION_PATH, isolated_path)

        start = time.monotonic()
        spec = importlib.util.spec_from_file_location("timing_utils", isolated_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        elapsed = time.monotonic() - start

    assert elapsed < 10.0, (
        f"Importing utils.py took {elapsed:.1f}s, which suggests the "
        f"submission is retraining a model at import time rather than "
        f"loading an already-fitted one, as instruction.md requires"
    )


# ---------------------------------------------------------------------
# Performance tests (the actual grading signal)
# ---------------------------------------------------------------------

def test_beats_constant_baseline(predictions, holdout_X_y):
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert auc >= MIN_ACCEPTABLE_AUC, (
        f"AUC {auc:.4f} does not clear the minimum acceptable bar "
        f"({MIN_ACCEPTABLE_AUC}); a constant-prediction baseline scores "
        f"{BASELINE_AUC}. Note that naively target-encoding bean_lot_id "
        f"(or any feature that only 'works' for lots seen during "
        f"training) will land in this failing range, since every holdout "
        f"lot is unseen."
    )


def test_does_not_exceed_leak_ceiling(predictions, holdout_X_y):
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert auc < LEAK_CEILING_AUC, (
        f"AUC {auc:.4f} meets or exceeds the leak-reference ceiling "
        f"({LEAK_CEILING_AUC}). Performance this high on this dataset "
        f"is only achievable by relying on information that would not "
        f"genuinely be available when a roast finishes -- check for "
        f"target leakage or preprocessing fit on data outside the "
        f"training split."
    )


def test_auc_within_golden_band(predictions, holdout_X_y):
    """Single combined pass/fail signal, kept separate from the two tests
    above so a failure message pinpoints which side was violated without
    needing to read this test's internals."""
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert MIN_ACCEPTABLE_AUC <= auc < LEAK_CEILING_AUC, (
        f"AUC {auc:.4f} outside acceptable band "
        f"[{MIN_ACCEPTABLE_AUC}, {LEAK_CEILING_AUC})"
    )
