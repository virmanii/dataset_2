"""
Golden reference solution for the coffee-roast-defect stacked-leakage task.

This script is run by the task author / eval harness only, to confirm the
task is solvable and that a correct submission passes tests/test_output.py.
It is NOT shown to the agent under evaluation.

It trains a model using only fields genuinely available at the moment a
roast batch finishes (before QC cupping happens, days later), then embeds
the fitted pipeline directly inside a generated /app/result/utils.py so the
deliverable is a single self-contained file with no external weight files.

Three things are deliberately NOT used as features, each for a different
reason -- see the comments below:
  - cupping_score_final, defect_classification, days_to_customer_complaint,
    batch_pulled_from_sale, refund_amount_total  (Trap 1: post-roast,
                                                   determined by QC cupping
                                                   days later; obviously so
                                                   by name)
  - qc_preview_score                             (Trap 2: LOOKS like a
                                                   roast-time sniff-test
                                                   score, but is only
                                                   recorded after a specific
                                                   hire date and is itself
                                                   informed by the actual
                                                   defect outcome -- a
                                                   silent leak that isn't
                                                   obvious from the column
                                                   name alone)
  - bean_lot_id (used raw / target-encoded)       (Trap 3: naive
                                                   target-encoding of a
                                                   repeat identifier
                                                   massively overfits, since
                                                   holdout lots are entirely
                                                   unseen. num_prior_roasts_
                                                   this_lot and
                                                   prior_defect_ever already
                                                   capture the genuinely
                                                   useful, generalizable
                                                   part of a lot's history
                                                   without memorizing
                                                   identity.)
"""

import base64
import pickle
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DATA_PATH = Path("/app/data/dataset.csv")
OUT_PATH = Path("/app/result/utils.py")

NUMERIC_COLS = [
    "green_bean_moisture_pct", "altitude_m", "batch_weight_kg", "charge_temp_c",
    "total_roast_time_min", "first_crack_time_min", "drop_temp_c",
    "ambient_humidity_pct", "ambient_temp_c", "num_prior_roasts_this_lot",
]
CATEGORICAL_COLS = ["origin_country", "processing_method", "roaster_machine_id", "prior_defect_ever"]
FEATURE_COLS = NUMERIC_COLS + CATEGORICAL_COLS


def build_pipeline() -> Pipeline:
    preprocessor = ColumnTransformer([
        ("num", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), NUMERIC_COLS),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_COLS),
    ])
    model = GradientBoostingClassifier(
        n_estimators=150, max_depth=3, learning_rate=0.1, random_state=0
    )
    return Pipeline([("pre", preprocessor), ("clf", model)])


def main():
    df = pd.read_csv(DATA_PATH)

    X = df[FEATURE_COLS]
    y = df["defect"]

    pipeline = build_pipeline()
    pipeline.fit(X, y)

    model_b64 = base64.b64encode(pickle.dumps(pipeline)).decode("ascii")

    module_source = f'''"""
Self-contained inference module.

The model was trained offline on genuinely roast-time features only (see
solution.py in the reference solution for training code) and is embedded
below as a base64-encoded pickled scikit-learn Pipeline. No external files,
no network access, no retraining at import time.
"""

import base64
import pickle

import pandas as pd

_MODEL_B64 = "{model_b64}"

_FEATURE_COLS = {FEATURE_COLS!r}


class _Result:
    def __init__(self):
        self._pipeline = pickle.loads(base64.b64decode(_MODEL_B64))

    def predict(self, df: pd.DataFrame):
        X = df[_FEATURE_COLS]
        return self._pipeline.predict_proba(X)[:, 1]


result = _Result()
'''

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(module_source)
    print(f"Wrote {OUT_PATH} ({len(module_source)} chars, model {len(model_b64)} b64 chars)")


if __name__ == "__main__":
    main()
