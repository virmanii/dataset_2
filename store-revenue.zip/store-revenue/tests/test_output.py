"""
Verifier for silent_merge_quarterly_revenue.

Checks:
  1. quarterly_store_revenue.csv exists, has correct schema
  2. every (store_id, fiscal_quarter) row matches golden within tolerance
  3. no extraneous rows (test stores leaked, wrong fiscal-quarter labels, etc.)
  4. answer.txt demonstrates recognition of the North backfill data artifact,
     not just a correct-looking percentage claim
"""
import os
import re
import pandas as pd
import pytest

WORKDIR = os.environ.get("AGENT_WORKDIR", "/app")
GOLDEN_PATH = os.path.join(os.path.dirname(__file__), "golden_quarterly_store_revenue.csv")

REQUIRED_COLUMNS = ["store_id", "fiscal_quarter", "net_revenue_usd", "transaction_count"]
REVENUE_ABS_TOL = 1.00   # dollars
REVENUE_REL_TOL = 0.01   # 1%


@pytest.fixture(scope="module")
def golden():
    return pd.read_csv(GOLDEN_PATH)


@pytest.fixture(scope="module")
def agent_output():
    path = os.path.join(WORKDIR, "quarterly_store_revenue.csv")
    assert os.path.exists(path), f"quarterly_store_revenue.csv not found at {path}"
    df = pd.read_csv(path)
    return df


def test_schema(agent_output):
    for col in REQUIRED_COLUMNS:
        assert col in agent_output.columns, f"missing required column: {col}"


def test_no_test_stores_leaked(agent_output):
    excluded = {401, 402, 9001}
    leaked = set(agent_output["store_id"].astype(int)) & excluded
    assert not leaked, f"test/dummy stores present in output: {leaked}"


def test_fiscal_quarter_labels_well_formed(agent_output):
    pattern = re.compile(r"^FY\d{4}-Q[1-4]$")
    bad = [q for q in agent_output["fiscal_quarter"].unique() if not pattern.match(str(q))]
    assert not bad, f"malformed fiscal_quarter labels: {bad}"


def test_row_coverage_matches_golden(agent_output, golden):
    agent_keys = set(zip(agent_output["store_id"].astype(int), agent_output["fiscal_quarter"]))
    golden_keys = set(zip(golden["store_id"].astype(int), golden["fiscal_quarter"]))
    missing = golden_keys - agent_keys
    extra = agent_keys - golden_keys
    assert not missing, f"missing (store_id, fiscal_quarter) rows: {sorted(missing)[:10]}"
    assert not extra, f"unexpected extra rows not in golden: {sorted(extra)[:10]}"


def test_revenue_values_match_golden(agent_output, golden):
    merged = golden.merge(
        agent_output, on=["store_id", "fiscal_quarter"], suffixes=("_gold", "_agent")
    )
    failures = []
    for _, row in merged.iterrows():
        gold = row["net_revenue_usd_gold"]
        agent = row["net_revenue_usd_agent"]
        tol = max(REVENUE_ABS_TOL, abs(gold) * REVENUE_REL_TOL)
        if abs(gold - agent) > tol:
            failures.append((row["store_id"], row["fiscal_quarter"], gold, agent))
    assert not failures, f"revenue mismatches (store, quarter, golden, agent): {failures[:10]}"


def test_transaction_counts_match_golden(agent_output, golden):
    merged = golden.merge(
        agent_output, on=["store_id", "fiscal_quarter"], suffixes=("_gold", "_agent")
    )
    mismatches = merged[merged["transaction_count_gold"] != merged["transaction_count_agent"]]
    assert mismatches.empty, (
        f"transaction_count mismatches:\n"
        f"{mismatches[['store_id','fiscal_quarter','transaction_count_gold','transaction_count_agent']]}"
    )


def test_answer_identifies_the_artifact():
    path = os.path.join(WORKDIR, "answer.txt")
    assert os.path.exists(path), f"answer.txt not found at {path}"
    text = open(path).read().lower()

    mentions_artifact_language = any(
        kw in text for kw in ["artifact", "backfill", "anomal", "data quality", "one-day", "single day", "duplicate ingest"]
    )
    mentions_correct_store_or_date = any(
        kw in text for kw in ["103", "2024-03-15", "march 15"]
    )
    claims_north_or_relevant_region = "north" in text

    assert claims_north_or_relevant_region, "answer.txt does not name the region with highest apparent growth (North)"
    assert mentions_artifact_language, (
        "answer.txt does not identify the growth as a data artifact "
        "(expected language like 'artifact', 'backfill', 'anomaly', etc.)"
    )
    assert mentions_correct_store_or_date, (
        "answer.txt does not cite the specific evidence (store 103 / 2024-03-15) "
        "for the artifact claim -- a correct-sounding but unsubstantiated answer should not pass"
    )
