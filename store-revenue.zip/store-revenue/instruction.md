# Task: Quarterly Store Revenue Reconciliation

You are given the following CSV files exported from a retail chain's systems:

- `/app/data/transactions_2023.csv`, `/app/data/transactions_2024.csv` — raw point-of-sale transactions
- `/app/data/store_metadata.csv` — store master data
- `/app/data/product_catalog.csv` — product reference data
- `/app/data/returns_log.csv` — customer returns
- `/app/data/regional_calendar.csv` — contains, among other things, a dated FX-rate table

## Required output

`/app/quarterly_store_revenue.csv` must report net revenue per store per fiscal quarter,
with exactly these columns: `store_id, fiscal_quarter, net_revenue_usd, transaction_count`.
For it to be correct, every one of the following must hold:

- **No duplicate transactions.** A small number of transactions appear in **both** yearly
  extracts due to a batch-export overlap around the fiscal year boundary. Each real-world
  transaction (identified by `transaction_id`) must be counted exactly once. Where a
  duplicate pair conflicts, the row with a non-empty `pos_terminal_id` is the
  POS-confirmed version and is the one that counts.
- **No test/dummy stores.** These are flagged inconsistently — there is no single reliable
  column in `/app/data/store_metadata.csv`. A store is only excluded if it's actually a
  test/dummy store; use every applicable signal you can find, not just one.
- **Every amount is in USD**, converted using the FX rate that was in effect on that
  transaction's own date. `/app/data/regional_calendar.csv` gives a dated rate table —
  rates change over time, so a transaction's rate is never today's rate or simply the
  latest rate.
- **Revenue is net of returns.** Each return should reduce the revenue of the transaction
  it belongs to. Where a return references its original transaction, use that. Where it
  doesn't, it should still be matched to the most plausible transaction — same store,
  within a few days, closest in amount. A return that can't plausibly be tied to a real
  store shouldn't reduce anyone's revenue.
- **`fiscal_quarter` labels are `FY<year>-Q<n>`**, where the fiscal year starts July 1
  (Q1 = Jul–Sep, Q2 = Oct–Dec, Q3 = Jan–Mar, Q4 = Apr–Jun) and `<year>` is the calendar
  year the fiscal year **ends** in (e.g. Jan–Mar 2024 falls in `FY2024-Q3`).

`/app/answer.txt` must contain a short answer (2–5 sentences) to: **which region had the
highest quarter-over-quarter revenue growth between fiscal Q2 2024 and fiscal Q3 2024, and
what actually caused it** — organic growth, a new store opening, or a data artifact? An
acceptable answer names the right cause and justifies it with specifics from the data, not
just the growth percentage.

## Notes

- Show your work; intermediate scripts are fine to leave in `/app`.
- All monetary amounts in the source files are in the currency shown in
  each transaction's `currency` column, not USD.
- Assume nothing about which stores or transactions are "obviously" fine —
  verify against the data.
