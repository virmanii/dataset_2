import math
from pathlib import Path
from datetime import datetime, timezone

import pandas as pd

DATA_DIR = Path("data")
OUTPUT_DIR = Path("output")


def parse_utc(ts: str) -> datetime:
    """Parse an ISO-8601 timestamp with explicit offset (or 'Z') into an aware UTC datetime."""
    s = ts.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    return dt.astimezone(timezone.utc)


def load_inputs():
    warehouses = pd.read_csv(DATA_DIR / "warehouses.csv")
    skus = pd.read_csv(DATA_DIR / "skus.csv")
    transactions = pd.read_csv(DATA_DIR / "transactions.csv", dtype={"reference_transaction_id": str})
    transactions["reference_transaction_id"] = transactions["reference_transaction_id"].fillna("")
    return warehouses, skus, transactions


def clean_transactions(transactions: pd.DataFrame, warehouses: pd.DataFrame, skus: pd.DataFrame) -> pd.DataFrame:
    df = transactions.copy()

    # Exact-duplicate transaction_id rows collapse to a single transaction.
    df = df.drop_duplicates(subset="transaction_id", keep="first")

    # Only transactions referencing a real warehouse and SKU are usable.
    valid_warehouses = set(warehouses["warehouse_id"])
    valid_skus = set(skus["sku_id"])
    df = df[df["warehouse_id"].isin(valid_warehouses) & df["sku_id"].isin(valid_skus)]

    # RECEIPT and SALE quantities are physical movements and must be non-negative.
    bad_sign = df["type"].isin(["RECEIPT", "SALE"]) & (df["quantity"] < 0)
    df = df[~bad_sign]

    # Normalize timestamps to aware UTC datetimes for correct chronological ordering.
    df = df.copy()
    df["ts_utc"] = df["timestamp"].apply(parse_utc)

    return df.reset_index(drop=True)


def resolve_cancellations(df: pd.DataFrame) -> pd.DataFrame:
    """Remove the effect of any transaction validly cancelled. Only RECEIPT/SALE/RETURN
    are cancellable; a CANCEL referencing anything else (or a nonexistent/invalid
    transaction) is itself dropped without effect."""
    cancel_rows = df[df["type"] == "CANCEL"]
    voided_ids = set()
    cancel_ids_to_drop = set(cancel_rows["transaction_id"])

    type_by_id = dict(zip(df["transaction_id"], df["type"]))

    for _, row in cancel_rows.iterrows():
        ref_id = row["reference_transaction_id"]
        ref_type = type_by_id.get(ref_id)
        if ref_type in ("RECEIPT", "SALE", "RETURN"):
            voided_ids.add(ref_id)

    keep_mask = (~df["transaction_id"].isin(cancel_ids_to_drop)) & (~df["transaction_id"].isin(voided_ids))
    return df[keep_mask]


def reconcile_stock(df: pd.DataFrame, warehouse_id: str, sku_id: str) -> int:
    pair = df[(df["warehouse_id"] == warehouse_id) & (df["sku_id"] == sku_id)]

    adjustments = pair[pair["type"] == "ADJUSTMENT"].sort_values(
        by=["ts_utc", "transaction_id"], ascending=[True, True]
    )

    if len(adjustments) > 0:
        baseline_row = adjustments.iloc[-1]
        baseline_stock = int(baseline_row["quantity"])
        baseline_time = baseline_row["ts_utc"]
        movements = pair[(pair["type"].isin(["RECEIPT", "SALE", "RETURN"])) & (pair["ts_utc"] > baseline_time)]
    else:
        baseline_stock = 0
        movements = pair[pair["type"].isin(["RECEIPT", "SALE", "RETURN"])]

    delta = 0
    for _, m in movements.iterrows():
        if m["type"] == "RECEIPT":
            delta += m["quantity"]
        elif m["type"] == "SALE":
            delta -= m["quantity"]
        elif m["type"] == "RETURN":
            delta += m["quantity"]

    return int(baseline_stock + delta)


def build_replenishment_plan(warehouses: pd.DataFrame, skus: pd.DataFrame, ledger: pd.DataFrame) -> pd.DataFrame:
    skus_by_id = skus.set_index("sku_id")
    rows = []

    for _, wh in warehouses.iterrows():
        wh_id = wh["warehouse_id"]
        capacity = wh["storage_capacity_units"]

        wh_rows = []
        for _, sk in skus.iterrows():
            sku_id = sk["sku_id"]
            current_stock = reconcile_stock(ledger, wh_id, sku_id)

            reorder_point = math.ceil(sk["avg_daily_demand"] * (sk["lead_time_days"] + sk["safety_stock_days"]))

            if current_stock < reorder_point:
                raw_needed = reorder_point - current_stock
                moq = int(sk["moq"])
                recommended = math.ceil(raw_needed / moq) * moq
            else:
                recommended = 0

            wh_rows.append({
                "warehouse_id": wh_id,
                "sku_id": sku_id,
                "current_stock": current_stock,
                "reorder_point": int(reorder_point),
                "recommended_order_qty": int(recommended),
            })

        # Capacity-constrained allocation within this warehouse.
        floor_stock_sum = sum(max(0, r["current_stock"]) for r in wh_rows)
        total_needed = floor_stock_sum + sum(r["recommended_order_qty"] for r in wh_rows)

        if total_needed > capacity:
            def urgency_key(r):
                sku_id = r["sku_id"]
                ratio = r["current_stock"] / r["reorder_point"]
                return (ratio, sku_id)

            priority_order = sorted(wh_rows, key=urgency_key)

            running_total = floor_stock_sum
            cutoff_triggered = False
            for r in priority_order:
                if cutoff_triggered:
                    r["recommended_order_qty"] = 0
                    continue
                tentative = running_total + r["recommended_order_qty"]
                if tentative <= capacity:
                    running_total = tentative
                else:
                    r["recommended_order_qty"] = 0
                    cutoff_triggered = True

        rows.extend(wh_rows)

    plan = pd.DataFrame(rows, columns=[
        "warehouse_id", "sku_id", "current_stock", "reorder_point", "recommended_order_qty"
    ])
    plan = plan.sort_values(by=["warehouse_id", "sku_id"]).reset_index(drop=True)
    return plan


def main():
    warehouses, skus, transactions = load_inputs()
    cleaned = clean_transactions(transactions, warehouses, skus)
    ledger = resolve_cancellations(cleaned)
    plan = build_replenishment_plan(warehouses, skus, ledger)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    plan.to_csv(OUTPUT_DIR / "replenishment_plan.csv", index=False)
    print(f"Wrote {len(plan)} rows to {OUTPUT_DIR / 'replenishment_plan.csv'}")


if __name__ == "__main__":
    main()
