"""
Test suite for the Multi-Warehouse Inventory Reconciliation & Replenishment task.

Two kinds of checks are used:
  1. Invariant checks — derived independently from data/warehouses.csv and
     data/skus.csv, without reference to the golden solution. These catch
     violations of a rule regardless of how the agent implemented it.
  2. Golden-comparison checks — compare specific rows (or the whole file)
     against tests/expected_output.csv, produced once by the reference
     solution. These pin down rules (tie-breaks, rounding direction, latest-
     adjustment-wins, etc.) that have more than one "plausible" reading.
"""
import math
from pathlib import Path

import pandas as pd
import pytest

TESTS_DIR = Path(__file__).parent

# At grading time, /tests (this file's directory) is mounted separately from
# the working directory the agent's solution actually runs in (WORKDIR /app
# in the Dockerfile). data/ and output/ must therefore be resolved relative
# to the current working directory, not relative to this file.
OUTPUT_PATH = Path("output") / "replenishment_plan.csv"
DATA_DIR = Path("data")

# expected_output.csv ships alongside this test file and is loaded from there.
EXPECTED_PATH = TESTS_DIR / "expected_output.csv"

EXPECTED_COLUMNS = ["warehouse_id", "sku_id", "current_stock", "reorder_point", "recommended_order_qty"]

# Warehouses whose total demand never exceeds capacity in this dataset, so the
# capacity-cutoff rule never fires for them (verified against the reference
# solution at data-generation time). Used to isolate the order-sizing rules
# from the capacity-allocation rule.
UNCONSTRAINED_WAREHOUSES = ["WH-DEL", "WH-MUM", "WH-BLR", "WH-HYD"]
CAPACITY_CONSTRAINED_WAREHOUSE = "WH-KOL"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def output_df():
    assert OUTPUT_PATH.exists(), (
        f"Expected output file not found at {OUTPUT_PATH}. "
        "The solution must write output/replenishment_plan.csv."
    )
    df = pd.read_csv(OUTPUT_PATH)
    return df


@pytest.fixture(scope="module")
def expected_df():
    return pd.read_csv(EXPECTED_PATH)


@pytest.fixture(scope="module")
def warehouses_df():
    return pd.read_csv(DATA_DIR / "warehouses.csv")


@pytest.fixture(scope="module")
def skus_df():
    return pd.read_csv(DATA_DIR / "skus.csv")


def _row(df, warehouse_id, sku_id):
    match = df[(df["warehouse_id"] == warehouse_id) & (df["sku_id"] == sku_id)]
    assert len(match) == 1, f"Expected exactly one row for ({warehouse_id}, {sku_id}), found {len(match)}"
    return match.iloc[0]


# ---------------------------------------------------------------------------
# Output contract / structural checks
# ---------------------------------------------------------------------------

def test_output_file_exists():
    assert OUTPUT_PATH.exists(), f"output/replenishment_plan.csv was not created at {OUTPUT_PATH}"


def test_output_schema_columns(output_df):
    assert list(output_df.columns) == EXPECTED_COLUMNS, (
        f"Column names/order must be exactly {EXPECTED_COLUMNS}, got {list(output_df.columns)}"
    )


def test_output_row_count_and_pair_coverage(output_df, expected_df):
    # warehouses.csv / skus.csv deliberately contain sandbox/test rows that must be
    # excluded, so the correct pair set is not the literal file cross-product --
    # it's whatever the reference solution determined to be real production entities.
    expected_pairs = set(zip(expected_df["warehouse_id"], expected_df["sku_id"]))
    assert len(output_df) == len(expected_pairs), (
        f"Expected {len(expected_pairs)} rows (one per real production warehouse/SKU pair), "
        f"got {len(output_df)}"
    )

    pairs = set(zip(output_df["warehouse_id"], output_df["sku_id"]))
    assert len(pairs) == len(output_df), "Output must contain exactly one row per (warehouse_id, sku_id) pair, no duplicates"
    assert pairs == expected_pairs, (
        "Output pairs don't match the real production (warehouse_id, sku_id) pairs. "
        "Check that sandbox/test rows in the master files were excluded (and that no "
        "real pair was dropped)."
    )


def test_sandbox_entities_excluded(output_df):
    """warehouses.csv and skus.csv each contain deliberately-planted sandbox/test rows
    (identifiable via a combination of an implausible cost/demand/MOQ profile, a
    suspicious name/category, or an outlier capacity -- not any single flag column).
    None of them should appear in the output, regardless of which exact heuristic
    was used to catch them."""
    assert not (output_df["warehouse_id"] == "WH-SBX").any(), (
        "WH-SBX is a sandbox/test warehouse (see its name and its outlier "
        "storage_capacity_units) and must not appear in the output"
    )
    assert not (output_df["sku_id"] == "SKU-016").any(), (
        "SKU-016 is a sandbox/test SKU (zero unit_cost, zero avg_daily_demand, moq=1) "
        "and must not appear in the output"
    )
    assert not (output_df["sku_id"] == "SKU-017").any(), (
        "SKU-017 is a sandbox/test SKU (category 'zzz_internal_test') and must not "
        "appear in the output"
    )


def test_output_sort_order(output_df):
    sorted_df = output_df.sort_values(by=["warehouse_id", "sku_id"]).reset_index(drop=True)
    pd.testing.assert_frame_equal(
        output_df.reset_index(drop=True), sorted_df,
        obj="Output rows must be sorted by warehouse_id ascending, then sku_id ascending"
    )


def test_output_values_are_integers(output_df):
    for col in ["current_stock", "reorder_point", "recommended_order_qty"]:
        assert output_df[col].notna().all(), f"Column {col} must not contain nulls"
        non_integer = output_df[col][output_df[col] != output_df[col].astype(int)]
        assert non_integer.empty, f"Column {col} must contain only integers, found: {non_integer.tolist()}"


def test_no_invalid_references_leaked_into_output(output_df):
    # These IDs only appear on deliberately-invalid transaction rows and must
    # never surface as legitimate warehouse/SKU identifiers in the output.
    assert "WH-XXX" not in set(output_df["warehouse_id"])
    assert "SKU-999" not in set(output_df["sku_id"])


# ---------------------------------------------------------------------------
# Invariant checks (independently derivable, no golden CSV needed)
# ---------------------------------------------------------------------------

def test_reorder_point_formula(output_df, skus_df):
    """reorder_point = ceil(avg_daily_demand * (lead_time_days + safety_stock_days)),
    and must be identical across every warehouse for a given SKU."""
    for _, sk in skus_df.iterrows():
        expected_rp = math.ceil(sk["avg_daily_demand"] * (sk["lead_time_days"] + sk["safety_stock_days"]))
        rows = output_df[output_df["sku_id"] == sk["sku_id"]]
        assert (rows["reorder_point"] == expected_rp).all(), (
            f"reorder_point for {sk['sku_id']} must equal {expected_rp} in every warehouse, "
            f"got {sorted(rows['reorder_point'].unique())}"
        )


def test_recommended_qty_is_nonnegative(output_df):
    assert (output_df["recommended_order_qty"] >= 0).all(), "recommended_order_qty must never be negative"


def test_recommended_qty_is_multiple_of_moq(output_df, skus_df):
    moq_by_sku = dict(zip(skus_df["sku_id"], skus_df["moq"]))
    for _, row in output_df.iterrows():
        moq = moq_by_sku[row["sku_id"]]
        assert row["recommended_order_qty"] % moq == 0, (
            f"recommended_order_qty for ({row['warehouse_id']}, {row['sku_id']}) = "
            f"{row['recommended_order_qty']} is not a multiple of its MOQ ({moq}); "
            "partial-MOQ orders are not allowed"
        )


def test_order_sizing_self_consistent_in_unconstrained_warehouses(output_df, skus_df):
    """Where the capacity rule never fires, recommended_order_qty must be fully
    derivable from that row's own current_stock, reorder_point, and moq."""
    moq_by_sku = dict(zip(skus_df["sku_id"], skus_df["moq"]))
    subset = output_df[output_df["warehouse_id"].isin(UNCONSTRAINED_WAREHOUSES)]
    for _, row in subset.iterrows():
        moq = moq_by_sku[row["sku_id"]]
        if row["current_stock"] < row["reorder_point"]:
            raw_needed = row["reorder_point"] - row["current_stock"]
            expected = math.ceil(raw_needed / moq) * moq
        else:
            expected = 0
        assert row["recommended_order_qty"] == expected, (
            f"({row['warehouse_id']}, {row['sku_id']}): current_stock={row['current_stock']}, "
            f"reorder_point={row['reorder_point']}, moq={moq} implies recommended_order_qty="
            f"{expected}, got {row['recommended_order_qty']}"
        )


def test_capacity_constraint_never_exceeded(output_df, warehouses_df):
    """No warehouse's floored current stock plus recommended orders may exceed
    its storage_capacity_units."""
    capacity_by_wh = dict(zip(warehouses_df["warehouse_id"], warehouses_df["storage_capacity_units"]))
    for wh_id, group in output_df.groupby("warehouse_id"):
        floor_stock = group["current_stock"].clip(lower=0).sum()
        total = floor_stock + group["recommended_order_qty"].sum()
        assert total <= capacity_by_wh[wh_id], (
            f"{wh_id}: floored stock ({floor_stock}) + recommended orders "
            f"({group['recommended_order_qty'].sum()}) = {total} exceeds capacity "
            f"({capacity_by_wh[wh_id]})"
        )


def test_negative_stock_is_not_clamped(output_df):
    """At least one pair in this dataset is a deliberate backorder scenario;
    current_stock must be allowed to go negative rather than floored at 0."""
    assert (output_df["current_stock"] < 0).any(), (
        "current_stock must not be clamped at zero — this dataset contains a deliberate "
        "backorder case that should show up as a negative value somewhere in the output"
    )


# ---------------------------------------------------------------------------
# Golden-comparison checks (pin down rules with more than one plausible reading)
# ---------------------------------------------------------------------------

def test_exact_duplicate_transaction_deduplicated(output_df, expected_df):
    """(WH-BLR, SKU-014) has an exact-duplicate transaction_id row in the raw
    log. If it were double-counted, current_stock would be wrong."""
    got = _row(output_df, "WH-BLR", "SKU-014")
    exp = _row(expected_df, "WH-BLR", "SKU-014")
    assert got["current_stock"] == exp["current_stock"], (
        f"(WH-BLR, SKU-014) current_stock={got['current_stock']}, expected {exp['current_stock']}. "
        "A duplicate transaction_id row was likely double-counted instead of deduplicated."
    )


def test_adjustment_absolute_and_latest_wins(output_df, expected_df):
    """(WH-DEL, SKU-013) has two ADJUSTMENT rows. Only the chronologically
    latest one (by UTC time) should set the baseline; ADJUSTMENT must be
    treated as an absolute stock count, not a delta added to prior history."""
    got = _row(output_df, "WH-DEL", "SKU-013")
    exp = _row(expected_df, "WH-DEL", "SKU-013")
    assert got["current_stock"] == exp["current_stock"], (
        f"(WH-DEL, SKU-013) current_stock={got['current_stock']}, expected {exp['current_stock']}. "
        "Check that ADJUSTMENT is treated as an absolute value and that the chronologically "
        "latest ADJUSTMENT (after UTC timezone normalization) wins."
    )


@pytest.mark.parametrize("warehouse_id,sku_id", [
    ("WH-MUM", "SKU-012"),
    ("WH-KOL", "SKU-013"),
    ("WH-KOL", "SKU-001"),
])
def test_cancel_of_adjustment_is_invalid_and_ignored(output_df, expected_df, warehouse_id, sku_id):
    """These pairs each have a CANCEL transaction whose reference_transaction_id
    points at an ADJUSTMENT row. Adjustments are not cancellable — the CANCEL
    must be dropped with no effect, leaving the ADJUSTMENT baseline intact."""
    got = _row(output_df, warehouse_id, sku_id)
    exp = _row(expected_df, warehouse_id, sku_id)
    assert got["current_stock"] == exp["current_stock"], (
        f"({warehouse_id}, {sku_id}) current_stock={got['current_stock']}, expected {exp['current_stock']}. "
        "A CANCEL referencing an ADJUSTMENT must have no effect (ADJUSTMENTs cannot be cancelled)."
    )


def test_valid_cancellation_voids_referenced_transaction(output_df, expected_df):
    """(WH-HYD, SKU-005) has a valid CANCEL that voids a SALE transaction.
    Both the CANCEL and its target must be excluded from the stock calculation."""
    got = _row(output_df, "WH-HYD", "SKU-005")
    exp = _row(expected_df, "WH-HYD", "SKU-005")
    assert got["current_stock"] == exp["current_stock"], (
        f"(WH-HYD, SKU-005) current_stock={got['current_stock']}, expected {exp['current_stock']}. "
        "A validly cancelled RECEIPT/SALE/RETURN must be excluded entirely from the reconciliation."
    )


def test_backorder_pair_matches_golden(output_df, expected_df):
    """(WH-DEL, SKU-011) is a deliberate heavy-backorder scenario with no
    ADJUSTMENT baseline at all."""
    got = _row(output_df, "WH-DEL", "SKU-011")
    exp = _row(expected_df, "WH-DEL", "SKU-011")
    assert got["current_stock"] == exp["current_stock"]
    assert got["recommended_order_qty"] == exp["recommended_order_qty"]


def test_capacity_priority_allocation_wh_kol(output_df, expected_df):
    """WH-KOL is deliberately calibrated so total demand lands exactly at its
    storage_capacity_units, forcing a genuine partial cutoff: some SKUs get
    their full recommended order, others (needing an order) get reduced to 0
    based on urgency (current_stock / reorder_point, ties by sku_id)."""
    got = output_df[output_df["warehouse_id"] == CAPACITY_CONSTRAINED_WAREHOUSE].sort_values("sku_id").reset_index(drop=True)
    exp = expected_df[expected_df["warehouse_id"] == CAPACITY_CONSTRAINED_WAREHOUSE].sort_values("sku_id").reset_index(drop=True)
    pd.testing.assert_frame_equal(
        got[["sku_id", "current_stock", "reorder_point", "recommended_order_qty"]],
        exp[["sku_id", "current_stock", "reorder_point", "recommended_order_qty"]],
        obj="WH-KOL rows must match the golden priority-based capacity allocation exactly"
    )


# ---------------------------------------------------------------------------
# Data quality write-up check
# ---------------------------------------------------------------------------

def test_anomaly_report_identifies_the_replay_cluster():
    """A cluster of 25 identical RECEIPT transactions (WH-HYD / SKU-009, qty=8,
    all within a few minutes on 2026-02-18) was deliberately injected into
    transactions.csv. It isn't mentioned anywhere in the instructions, so a
    correct write-up can only come from actually inspecting the data."""
    report_path = Path("anomaly_report.txt")
    assert report_path.exists(), f"anomaly_report.txt was not created at {report_path}"
    text = report_path.read_text().lower()

    mentions_warehouse = "wh-hyd" in text or "hyd" in text
    mentions_sku = "sku-009" in text
    mentions_date_or_count = ("2026-02-18" in text) or ("feb" in text and "18" in text) or ("25" in text)
    mentions_anomaly_language = any(
        kw in text for kw in ["replay", "retry", "duplicate", "glitch", "anomal", "bug", "suspicious", "inconsistent with organic"]
    )

    assert mentions_warehouse, "anomaly_report.txt does not identify the affected warehouse (WH-HYD)"
    assert mentions_sku, "anomaly_report.txt does not identify the affected SKU (SKU-009)"
    assert mentions_date_or_count, "anomaly_report.txt does not cite specific evidence (date or transaction count)"
    assert mentions_anomaly_language, (
        "anomaly_report.txt does not characterize this as a data quality anomaly "
        "(expected language like 'replay', 'duplicate', 'glitch', 'anomaly', etc.)"
    )


# ---------------------------------------------------------------------------
# Master check
# ---------------------------------------------------------------------------

def test_full_output_matches_golden_exactly(output_df, expected_df):
    got = output_df.sort_values(by=["warehouse_id", "sku_id"]).reset_index(drop=True)
    exp = expected_df.sort_values(by=["warehouse_id", "sku_id"]).reset_index(drop=True)
    pd.testing.assert_frame_equal(
        got, exp, obj="Full replenishment_plan.csv must match the golden solution exactly, row for row"
    )
