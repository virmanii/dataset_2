# Merchant Cash Advance Default Prediction

You are given underwriting records from a merchant cash advance lender, covering advances
issued to small businesses over a multi-year period. Each row is one advance application.
Your goal is to estimate the probability that an advance will default (`default`, binary)
using information available at the moment the merchant applies.

## Data

`/app/data/dataset.csv`

Each row contains fields recorded at or after an application, including (but not limited to):

- Application details: `merchant_id`, `application_date`, `requested_amount`, `industry_category`, `state`
- Merchant profile: `monthly_revenue_avg`, `time_in_business_years`, `credit_score_proxy`,
  `num_employees`, `debt_to_revenue`, `num_prior_advances`, `prior_default_ever`
- `secondary_risk_score` — an internal score attached to some applications
- `revenue_verification_score` — a score attached to some applications
- Servicing history and outcome-related fields recorded after the advance was issued
- `default` — whether the advance defaulted (target)

Not every column in this file is genuinely available at the moment a new application needs
to be scored. Some fields are only recorded once an advance's repayment history is already
underway or its outcome is known. Using such fields during model development can produce
misleadingly strong results on this file that do not hold up when scoring a real new
application — and in some cases will make your submission fail outright, since the
evaluation-time input won't contain them at all.

Two of the fields above are only populated for a subset of applications, and both correlate
with the outcome. That surface pattern alone doesn't tell you which of them, if either, is
safe to use — a field can be incomplete for entirely mundane reasons (e.g. it was optional,
or a merchant simply didn't provide it) and still be genuinely available at application
time and legitimately predictive. Excluding every field that looks even slightly suspicious
is not a safe default: it can just as easily throw away real, usable signal as it throws
away a leak. Investigate what actually explains each field's coverage and its relationship
to the outcome before deciding.

Some merchants in this file applied more than once over the years — you'll find repeated
`merchant_id` values. The merchants your model will be scored against at evaluation time
are entirely different businesses that never appear in this file. A feature or encoding
that relies on having seen a specific merchant before will not transfer to a brand-new one,
however well it appears to perform here.

## Task

Build a model that predicts default probability from information genuinely available at
the moment of application.

Your objective is **not simply to maximize performance on this file**, but to build a model
that produces valid, reliable predictions for new applications from merchants your model has
never encountered, based only on what is actually known at application time.

Before submitting, it is good practice to check exactly which fields and encodings your
model depends on, and whether each would realistically be known — and would generalize —
for a genuinely new applicant.

## Deliverable

Write `/app/result/utils.py` exposing a module-level object named `result` with a `predict`
method.

```python
result.predict(df)
```

`df` will contain only the fields that are genuinely available at application time, for
merchants your model has not seen before. It will not contain servicing-history,
outcome-related, or internal-score fields that aren't genuinely available at that point.

The method must return one predicted default probability (between 0 and 1) for each input
row, preserving row order.

## Requirements

Your submitted `utils.py` should:

- depend only on `numpy`, `pandas`, and `scikit-learn` at prediction time;
- contain everything needed for inference inside the file (no external weight files, no
  network calls, no retraining at import time);
- expose a module-level object named `result` implementing `result.predict(df)`;
- only reference columns that will actually be present in the `df` passed at evaluation
  time.

## Evaluation

Evaluation measures prediction quality (ROC AUC) on held-out applications from merchants
not present in `/app/data/dataset.csv`. Submissions are also compared against a simple
constant-prediction baseline, and against an upper reference band representing performance
that is only achievable by relying on information — or on memorizing specific merchants —
that would not genuinely generalize to a new applicant.
