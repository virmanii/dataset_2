"""
Atomic tests for the merchant-cash-advance stacked-leakage task.

Each test checks exactly one claim from instruction.md, and each is
independent (no test depends on another having run first, no shared
mutable state). A submission passes the task iff every test here
passes.

Assumes the submission has already produced /app/result/utils.py
inside the container. This file is run by the grading harness, not by
the agent -- neither this file nor holdout_eval.csv should be present
anywhere inside the agent's own working environment.
"""

import ast
import importlib.util
import shutil
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import roc_auc_score

SUBMISSION_PATH = Path("/app/result/utils.py")
HOLDOUT_PATH = Path(__file__).parent / "holdout_eval.csv"

FEATURE_COLS = [
    "merchant_id", "application_date", "industry_category", "state",
    "requested_amount", "monthly_revenue_avg", "time_in_business_years",
    "credit_score_proxy", "num_employees", "debt_to_revenue",
    "num_prior_advances", "prior_default_ever", "revenue_verification_score",
]

# Performance bands. The golden solution scores ~0.71 AUC on this holdout
# using every genuinely-available, genuinely-generalizable feature -- this
# INCLUDES revenue_verification_score, a partially-null field that looks
# structurally identical to the secondary_risk_score leak but is actually
# safe and predictive (see instruction.md). A blanket "exclude anything
# partially-null / suspicious-looking" strategy that drops it along with the
# real leak tops out at ~0.67 and fails the floor below -- discarding a
# genuine leak and discarding real signal are not the same mistake, and this
# task does not reward being unable to tell them apart. A model that
# naively target-encodes merchant_id (without safeguards for unseen IDs)
# collapses toward baseline on this holdout, since every holdout merchant
# is unseen.
BASELINE_AUC = 0.50
MIN_ACCEPTABLE_AUC = 0.70   # clears blanket-exclusion (~0.67 ceiling) and merchant-memorization collapse, requires the real signal
LEAK_CEILING_AUC = 0.80     # at/above this implies leakage, not skill

# Only these THIRD-PARTY top-level packages may be imported by the
# submission, per "depend only on numpy, pandas, and scikit-learn at
# prediction time". Standard-library modules are unrestricted.
ALLOWED_THIRD_PARTY_IMPORTS = {"numpy", "pandas", "sklearn"}
STDLIB_ALLOWLIST = {
    "pickle", "base64", "math", "json", "os", "sys", "typing",
    "functools", "itertools", "collections", "re", "warnings", "copy",
    "dataclasses", "abc", "io", "gzip", "zlib", "bz2", "lzma",
}
FORBIDDEN_MODULES = {
    "requests", "urllib", "urllib2", "socket", "http", "ftplib",
    "joblib", "torch", "tensorflow", "xgboost", "lightgbm", "catboost",
}


# ---------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------

@pytest.fixture(scope="module")
def submission_source() -> str:
    assert SUBMISSION_PATH.exists(), (
        f"Expected deliverable at {SUBMISSION_PATH}, but it does not exist."
    )
    return SUBMISSION_PATH.read_text()


@pytest.fixture(scope="module")
def result_module():
    spec = importlib.util.spec_from_file_location("submission_utils", SUBMISSION_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def holdout_df() -> pd.DataFrame:
    assert HOLDOUT_PATH.exists(), f"Missing holdout file at {HOLDOUT_PATH}"
    return pd.read_csv(HOLDOUT_PATH)


@pytest.fixture(scope="module")
def holdout_X_y(holdout_df):
    X = holdout_df[FEATURE_COLS].copy()
    y = holdout_df["default"].copy()
    return X, y


@pytest.fixture(scope="module")
def predictions(result_module, holdout_X_y):
    X, _ = holdout_X_y
    return np.asarray(result_module.result.predict(X))


# ---------------------------------------------------------------------
# Structural / interface tests
# ---------------------------------------------------------------------

def test_deliverable_file_exists():
    assert SUBMISSION_PATH.exists(), (
        "instruction.md requires writing /app/result/utils.py"
    )


def test_module_exposes_result_object(result_module):
    assert hasattr(result_module, "result"), (
        "utils.py must expose a module-level object named `result`"
    )


def test_result_has_predict_method(result_module):
    assert hasattr(result_module.result, "predict"), (
        "`result` must implement a `predict` method"
    )
    assert callable(result_module.result.predict)


def test_predict_accepts_origination_only_columns(result_module, holdout_X_y):
    """Traps 1 and 2: the eval-time df contains ONLY genuinely pre-origination
    columns -- no servicing-history, outcome-related, or secondary_risk_score
    field. If the submission's predict() reaches for any of those, this call
    raises and the test fails."""
    X, _ = holdout_X_y
    try:
        result_module.result.predict(X)
    except Exception as e:
        pytest.fail(
            "predict() failed when called with only the columns genuinely "
            f"available at application time (no servicing/outcome/internal-score "
            f"columns present). This usually means the model was trained on a "
            f"column that will not exist at evaluation time. Original error: {e!r}"
        )


def test_predict_handles_unseen_merchant_ids(result_module, holdout_X_y):
    """Trap 3: every merchant_id at evaluation time is one the model has never
    seen (a brand-new applicant). If merchant_id was used via a raw lookup
    (e.g. a dict built from the training file with no fallback for missing
    keys) rather than something that generalizes, this call raises."""
    X, _ = holdout_X_y
    X_fabricated = X.copy()
    X_fabricated["merchant_id"] = [f"UNSEEN-{i:06d}" for i in range(len(X_fabricated))]
    try:
        result_module.result.predict(X_fabricated)
    except Exception as e:
        pytest.fail(
            "predict() failed when given entirely novel merchant_id values. "
            "A submission must not depend on having seen a specific merchant "
            f"before. Original error: {e!r}"
        )


def test_predict_output_length_and_order(predictions, holdout_X_y):
    X, _ = holdout_X_y
    assert len(predictions) == len(X), (
        f"predict() must return one prediction per input row: "
        f"got {len(predictions)} predictions for {len(X)} rows"
    )


def test_predict_output_is_valid_probability(predictions):
    assert np.all(predictions >= 0.0) and np.all(predictions <= 1.0), (
        "predict() must return values in [0, 1] (a probability), "
        f"got range [{predictions.min()}, {predictions.max()}]"
    )
    assert not np.any(np.isnan(predictions)), "predict() returned NaN values"


def test_predict_is_deterministic(result_module, holdout_X_y):
    X, _ = holdout_X_y
    p1 = np.asarray(result_module.result.predict(X))
    p2 = np.asarray(result_module.result.predict(X))
    assert np.allclose(p1, p2), (
        "predict() must be deterministic given the same input "
        "(grading re-runs may call predict() more than once)"
    )


def test_predict_is_column_order_invariant(result_module, holdout_X_y):
    X, _ = holdout_X_y
    X_shuffled = X[list(reversed(X.columns))]
    p_original = np.asarray(result_module.result.predict(X))
    p_shuffled = np.asarray(result_module.result.predict(X_shuffled))
    assert np.allclose(p_original, p_shuffled), (
        "predict() output should not depend on input column order"
    )


# ---------------------------------------------------------------------
# Self-containment tests
# ---------------------------------------------------------------------

def test_only_allowed_third_party_imports(submission_source):
    tree = ast.parse(submission_source)
    top_level_imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                top_level_imports.add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                top_level_imports.add(node.module.split(".")[0])

    forbidden_hits = top_level_imports & FORBIDDEN_MODULES
    assert not forbidden_hits, (
        f"utils.py imports disallowed module(s): {forbidden_hits}"
    )

    unknown = top_level_imports - ALLOWED_THIRD_PARTY_IMPORTS - STDLIB_ALLOWLIST
    assert not unknown, (
        f"utils.py imports module(s) outside numpy/pandas/scikit-learn "
        f"and the standard library: {unknown}"
    )


def test_self_contained_no_external_files(holdout_X_y):
    X, _ = holdout_X_y
    with tempfile.TemporaryDirectory() as tmp:
        isolated_path = Path(tmp) / "utils.py"
        shutil.copy(SUBMISSION_PATH, isolated_path)

        spec = importlib.util.spec_from_file_location("isolated_utils", isolated_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        preds = module.result.predict(X)
        assert len(preds) == len(X)


def test_import_does_not_retrain(holdout_X_y):
    with tempfile.TemporaryDirectory() as tmp:
        isolated_path = Path(tmp) / "utils.py"
        shutil.copy(SUBMISSION_PATH, isolated_path)

        start = time.monotonic()
        spec = importlib.util.spec_from_file_location("timing_utils", isolated_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        elapsed = time.monotonic() - start

    assert elapsed < 10.0, (
        f"Importing utils.py took {elapsed:.1f}s, which suggests the "
        f"submission is retraining a model at import time rather than "
        f"loading an already-fitted one, as instruction.md requires"
    )


# ---------------------------------------------------------------------
# Performance tests (the actual grading signal)
# ---------------------------------------------------------------------

def test_beats_constant_baseline(predictions, holdout_X_y):
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert auc >= MIN_ACCEPTABLE_AUC, (
        f"AUC {auc:.4f} does not clear the minimum acceptable bar "
        f"({MIN_ACCEPTABLE_AUC}). A constant-prediction baseline scores "
        f"{BASELINE_AUC}. Naively target-encoding merchant_id, and also "
        f"blanket-excluding every partially-null or suspicious-looking "
        f"column (which discards real signal along with the leak), both "
        f"land in this failing range."
    )


def test_does_not_exceed_leak_ceiling(predictions, holdout_X_y):
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert auc < LEAK_CEILING_AUC, (
        f"AUC {auc:.4f} meets or exceeds the leak-reference ceiling "
        f"({LEAK_CEILING_AUC}). Performance this high on this dataset "
        f"is only achievable by relying on information that would not "
        f"genuinely be available at application time -- check for "
        f"target leakage or preprocessing fit on data outside the "
        f"training split."
    )


def test_auc_within_golden_band(predictions, holdout_X_y):
    """Single combined pass/fail signal, kept separate from the two tests
    above so a failure message pinpoints which side was violated without
    needing to read this test's internals."""
    _, y = holdout_X_y
    auc = roc_auc_score(y, predictions)
    assert MIN_ACCEPTABLE_AUC <= auc < LEAK_CEILING_AUC, (
        f"AUC {auc:.4f} outside acceptable band "
        f"[{MIN_ACCEPTABLE_AUC}, {LEAK_CEILING_AUC})"
    )
