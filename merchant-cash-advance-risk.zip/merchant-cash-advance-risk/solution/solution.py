"""
Golden reference solution for the merchant-cash-advance stacked-leakage task.

This script is run by the task author / eval harness only, to confirm the
task is solvable and that a correct submission passes tests/test_output.py.
It is NOT shown to the agent under evaluation.

It trains a model using only fields genuinely available at the moment a
merchant applies (before any repayment history exists), then embeds the
fitted pipeline directly inside a generated /app/result/utils.py so the
deliverable is a single self-contained file with no external weight files.

Four things are relevant to feature selection here, each requiring different
reasoning -- see the comments below:
  - days_to_first_missed_payment, total_recovered_amount,
    collections_status, last_payment_date   (Trap 1: post-origination,
                                              outcome-derived; obviously so
                                              by name -- EXCLUDED)
  - secondary_risk_score                    (Trap 2: LOOKS like an
                                              origination-time score, but is
                                              only populated after a legacy
                                              tool's rollout date and is
                                              itself informed by early
                                              repayment behavior -- a silent
                                              leak that isn't obvious from
                                              the column name alone --
                                              EXCLUDED)
  - merchant_id (used raw / target-encoded)  (Trap 3: naive target-encoding
                                              of a repeat identifier
                                              massively overfits, since
                                              holdout merchants are entirely
                                              unseen IDs. num_prior_advances
                                              and prior_default_ever already
                                              capture the genuinely useful,
                                              generalizable part of a
                                              merchant's history without
                                              memorizing identity --
                                              EXCLUDED)
  - revenue_verification_score               (RED HERRING: also partially
                                              null (~53%), also correlates
                                              with the target -- structurally
                                              it looks just like Trap 2. But
                                              its nullness reflects a
                                              merchant's own choice to submit
                                              optional bank-statement
                                              verification at application
                                              time, not a downstream/outcome
                                              artifact, and its value isn't
                                              informed by anything that
                                              happens after origination.
                                              Blanket-excluding every
                                              partially-null column drops
                                              this along with the real leak
                                              and loses real, legitimate
                                              signal -- INCLUDED)
"""

import base64
import pickle
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DATA_PATH = Path("/app/data/dataset.csv")
OUT_PATH = Path("/app/result/utils.py")

NUMERIC_COLS = [
    "requested_amount", "monthly_revenue_avg", "time_in_business_years",
    "credit_score_proxy", "num_employees", "debt_to_revenue", "num_prior_advances",
    "revenue_verification_score",
]
CATEGORICAL_COLS = ["industry_category", "state", "prior_default_ever"]
FEATURE_COLS = NUMERIC_COLS + CATEGORICAL_COLS


def build_pipeline() -> Pipeline:
    preprocessor = ColumnTransformer([
        ("num", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), NUMERIC_COLS),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL_COLS),
    ])
    model = GradientBoostingClassifier(
        n_estimators=150, max_depth=3, learning_rate=0.1, random_state=0
    )
    return Pipeline([("pre", preprocessor), ("clf", model)])


def main():
    df = pd.read_csv(DATA_PATH)

    X = df[FEATURE_COLS]
    y = df["default"]

    pipeline = build_pipeline()
    pipeline.fit(X, y)

    model_b64 = base64.b64encode(pickle.dumps(pipeline)).decode("ascii")

    module_source = f'''"""
Self-contained inference module.

The model was trained offline on genuinely origination-time features only
(see solution.py in the reference solution for training code) and is
embedded below as a base64-encoded pickled scikit-learn Pipeline.
No external files, no network access, no retraining at import time.
"""

import base64
import pickle

import pandas as pd

_MODEL_B64 = "{model_b64}"

_FEATURE_COLS = {FEATURE_COLS!r}


class _Result:
    def __init__(self):
        self._pipeline = pickle.loads(base64.b64decode(_MODEL_B64))

    def predict(self, df: pd.DataFrame):
        X = df[_FEATURE_COLS]
        return self._pipeline.predict_proba(X)[:, 1]


result = _Result()
'''

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(module_source)
    print(f"Wrote {OUT_PATH} ({len(module_source)} chars, model {len(model_b64)} b64 chars)")


if __name__ == "__main__":
    main()
